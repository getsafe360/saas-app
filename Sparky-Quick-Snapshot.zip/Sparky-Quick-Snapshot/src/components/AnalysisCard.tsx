import React from 'react';
import { LucideIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface AnalysisCardProps {
  title: string;
  icon: LucideIcon;
  content: string;
  isLoading?: boolean;
  className?: string;
  delay?: number;
}

export const AnalysisCard: React.FC<AnalysisCardProps> = ({ 
  title, 
  icon: Icon, 
  content, 
  isLoading, 
  className,
  delay = 0 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={cn(
        "group relative overflow-hidden rounded-xl border border-white/10 bg-[#151619] p-5 transition-all hover:border-white/20 hover:shadow-2xl hover:shadow-black/50",
        className
      )}
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/5 text-white/70 group-hover:text-white transition-colors">
          <Icon size={20} />
        </div>
        <h3 className="font-mono text-xs font-bold uppercase tracking-widest text-white/50 group-hover:text-white/80 transition-colors">
          {title}
        </h3>
      </div>

      <div className="min-h-[80px]">
        {isLoading ? (
          <div className="space-y-2">
            <div className="h-4 w-full animate-pulse rounded bg-white/5" />
            <div className="h-4 w-3/4 animate-pulse rounded bg-white/5" />
            <div className="h-4 w-1/2 animate-pulse rounded bg-white/5" />
          </div>
        ) : (
          <p className="font-sans text-sm leading-relaxed text-white/70">
            {content || "Awaiting signal..."}
          </p>
        )}
      </div>

      {/* Decorative hardware elements */}
      <div className="absolute top-2 right-2 flex gap-1">
        <div className="h-1 w-1 rounded-full bg-white/10" />
        <div className="h-1 w-1 rounded-full bg-white/10" />
      </div>
      <div className="absolute bottom-0 left-0 h-[1px] w-full bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    </motion.div>
  );
};
