export interface AnalysisResult {
  accessibility: string;
  performance: string;
  seo: string;
  security: string;
  content: string;
  wordpress?: {
    detected: boolean;
    version?: string;
    insights?: string;
  };
  summary: string;
  cta: string;
}

export type Category = 'accessibility' | 'performance' | 'seo' | 'security' | 'content' | 'wordpress';
